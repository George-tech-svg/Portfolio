# EmailJS Setup Guide for OTP Email Sending

Your portfolio is now configured to send OTP emails using **EmailJS**. Follow these steps to enable it:

## Step 1: Create EmailJS Account
1. Go to https://www.emailjs.com/
2. Sign up for a **FREE** account
3. Verify your email

## Step 2: Get Your Public Key
1. Log in to EmailJS
2. Go to **Account** → **General** tab
3. Copy your **Public Key** (looks like: `abc123def456ghi789`)

## Step 3: Set Up Email Service
1. In EmailJS dashboard, go to **Email Services**
2. Click **Add Service**
3. Choose **Gmail** or **Outlook** (or your email provider)
4. Follow the prompts to connect your email:
   - For Gmail: Use an **App Password** (enable 2-Factor Authentication first)
   - For Outlook: Use your Outlook password
5. Copy the **Service ID** (looks like: `service_abc123`)

## Step 4: Create Email Template
1. In EmailJS dashboard, go to **Email Templates**
2. Click **Create New Template**
3. **Template Name:** `otp_reset_template`
4. **Copy this template content:**

```
Subject: Your GEORGE ONYANGO PORTFOLIO - Password Reset OTP

From: GEORGE ONYANGO PORTFOLIO <{{from_name}}>
To: {{to_email}}

Body:
---

Hello,

You requested to reset your password. Your One-Time Password (OTP) is:

    {{otp_code}}

This OTP will expire in 5 minutes.

If you did not request this, please ignore this email.

Best regards,
GEORGE ONYANGO PORTFOLIO
George Onyango Ochieng
{{user_email}}

---
```

5. Save the template
6. Copy your **Template ID** (from URL or settings)

## Step 5: Update Your Portfolio Code
Open `index.html` and find this section (around line 2110):

```javascript
function initEmailJS() {
    try {
        emailjs.init("YOUR_EMAILJS_PUBLIC_KEY"); // ← Replace this
    } catch (e) {
        console.log('EmailJS not configured. Using demo mode.');
    }
}

function sendOTPEmail(email, otp) {
    const emailParams = {
        to_email: email,
        from_name: "GEORGE ONYANGO PORTFOLIO",
        otp_code: otp,
        user_email: email
    };
    
    try {
        emailjs.send("YOUR_SERVICE_ID", "YOUR_TEMPLATE_ID", emailParams) // ← Replace these
```

**Replace with your actual credentials:**
- `YOUR_EMAILJS_PUBLIC_KEY` → Your Public Key from Step 2
- `YOUR_SERVICE_ID` → Your Service ID from Step 3
- `YOUR_TEMPLATE_ID` → Your Template ID from Step 4

## Example (after replacement):

```javascript
emailjs.init("abc123def456ghi789");
emailjs.send("service_xyz123", "template_otp_123", emailParams)
```

## Step 6: Test It!
1. Refresh your portfolio
2. Login with test account
3. Click "Forgot password?"
4. Enter your registered email
5. You should receive an OTP email from GEORGE ONYANGO PORTFOLIO

## Troubleshooting

**Email not sending?**
- Check browser console (F12) for error messages
- Verify Public Key, Service ID, and Template ID are correct
- Make sure you've verified your email on EmailJS
- For Gmail: Verify App Password is correct

**Want to see the OTP for testing?**
- Open browser Developer Tools (F12)
- Go to Console tab
- You'll see: `🔐 Test OTP: 123456 for your@email.com`

**Billing concerns?**
- EmailJS free tier allows 200 emails/month
- Perfect for personal portfolio

---

**Need Help?**
- EmailJS Docs: https://www.emailjs.com/docs/
- Portfolio Support: Check browser console for errors

